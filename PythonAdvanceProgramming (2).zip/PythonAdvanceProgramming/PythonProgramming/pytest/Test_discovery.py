#test_discovery - rules used to create the pytest tests or testcase
# filename should start with test_
# functions should start with test_
# -v Verbose - show detailed output
#-s Show - show print statements
import pytest
def testcase1():
    print("testecase1 is executed")
def testcase2():
    print("testcase2 is executed")
def test_case3():
    print("testcase 3 is excecuted")
def openbrowser():
    print("open the browser")


