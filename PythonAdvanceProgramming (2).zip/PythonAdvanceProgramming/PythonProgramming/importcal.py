import Calculator
print(Calculator.add(2,5))
print(Calculator.sub(4,3))