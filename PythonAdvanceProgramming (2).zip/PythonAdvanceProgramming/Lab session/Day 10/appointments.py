from flask import Flask, jsonify, request
import requests

app = Flask(__name__)

BASE_URL = "https://127.0.0.1.5000/doctors.py"

@app.route("/posts", methods=["POST"])
def create_post():
    payload = request.json  # JSON body sent by client
    response = requests.post(f"{BASE_URL}/posts", json=payload)
    return jsonify(response.json()), response.status_code