#Parse HTML – Extract title and h1

from bs4 import BeautifulSoup
import requests

html = '''
<html>
<head><title>My Page</title></head>
<body>
<h1>Welcome</h1>
<p>This is a paragraph.</p>
</body>
</html>
'''
soup = BeautifulSoup(html,features  ="html.parser")
items = soup.find_all("title")
for item in items:
    print(item.text)
items = soup.find_all("h1")
for item in items:
    print(item.text)
#Extract All Paragraphs
items = soup.find_all("p")
for item in items:
    print(item.text)
# Extract All Links and Count
url = "http://books.toscrape.com/"
headers = {
    #user agent is making the request and from where
    "User-Agent" : "Chrome/120.0.0.0"
}
response = requests.get(url,headers = headers)
soup = BeautifulSoup(response.text,features="html.parser")
links = soup.find_all("a")
print(links)
print(len(links))
# Extract Attributes
# Extract First h2
items = soup.find_all("h2")
for item in items:
    print(item.text)
# Extract Bold Text
items = soup.find_all("b")
for item in items:
    print(item.text)
# Extract All href Values
for link in links:
    print(link.get("href"))
# Get All Text Without Tags
items = soup.find_all("div")
for item in items:
    print(item.text)
#Extract Title from Website
items = soup.find_all("title")
for item in items:
    print(item.text)
# Extract All Headings
items = soup.find_all("h3")
for item in items:
    print(item.text)
items = soup.find_all("h4")
for item in items:
    print(item.text)
items = soup.find_all("h5")
for item in items:
    print(item.text)
items = soup.find_all("h6")
for item in items:
    print(item.text)
#Extract Table Data
items = soup.find_all("table")
for table in soup.find_all("table"):
    for row in table.find_all("tr"):
        cells = row.find_all(["th", "td"])
        print([cell.get_text(strip=True) for cell in cells])
# Extract Images
items = soup.find_all("img")
for item in items:
    print(item['src'])