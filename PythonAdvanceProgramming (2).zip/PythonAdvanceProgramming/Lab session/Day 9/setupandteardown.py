#Write a test that is skipped because a feature is not implemented yet.
import pytest

from PythonProgramming.Getmethod import response


def test_case():
    print("feature is implemented")
@pytest.mark.skip
def test_case1():
    print("feature is not implemented")
#write a test that runs only on Linux and skips on Windows.
import pytest
def test_case2():
    print("Test runs only on linux")
@pytest.mark.skip
def test_case3():
    print("Test doesnt run on windows")

#Write a test that checks an API health endpoint.
import requests
def test_api():
    data = requests.get("https://videogamedb.uk:443/api/v2/videogame")
    #id api not healthy then skip dynamically
    if response.status_code != 200:
        pytest.skip(f"API not healthy.Status code:{data.status_code}")
    # if healthy so continue validation
    assert data.status_code == 200
#If status code is not 200 → skip the test dynamically.
import pytest
@pytest.mark.skip
def test_case4(status_code):
    if status_code != 200:
        print("Test is dynamically")
#Mark a failing test as xfail with reason: "Bug #123".
import pytest
@pytest.mark.xfail(reason = "Bug #123")
def test_case5():
    assert True

#You have 5 parameterized cases. 2 are known bugs. Mark only those 2 cases as xfail without marking entire test.
@pytest.mark.xfail(reason = "Number is not divisible by 5")
@pytest.mark.parametrize("num",[8])
def test_number(num):
    assert (num%5) == 0
@pytest.mark.parametrize("a,b,result",[(2,3,5),(4,5,9),(6,7,13)])
def test_add(a,b,result):
    assert a+b == result
@pytest.mark.parametrize("number",[2,4,6])
def test_add3(number):
    assert (number%2) == 0
@pytest.mark.parametrize("a,b,result",[(5,3,2),(6,2,4),(4,1,3)])
def test_add(a,b,result):
    assert a-b == result
@pytest.mark.xfail(reason = "Number is not even ")
@pytest.mark.parametrize("num1",[3])
def test_num2(num1):
    assert num1%2 == 0